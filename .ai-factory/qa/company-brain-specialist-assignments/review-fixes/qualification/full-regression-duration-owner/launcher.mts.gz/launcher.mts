import { spawn, execFileSync } from "node:child_process";
import { writeFile, readFile } from "node:fs/promises";
import { createRequire } from "node:module";
import {
  invocationFromEnvironment, fixtureProcessEnvironment, registerProcess,
  releaseInvocation, FIXTURE_WATCHDOG,
} from "/private/tmp/cb-stop-owner-full-ouypj3_d/web/test-support/process-invocation.ts";
import { retainLaneReaper } from "/private/tmp/cb-stop-owner-full-ouypj3_d/web/test-support/lane-reaper.ts";
const checkout = "/private/tmp/cb-stop-owner-full-ouypj3_d";
const head = "f203ad5fb";
const prefix = "/private/tmp/cb-stop-owner-full-result";
const git = (args) => execFileSync("git",args,{cwd:checkout,encoding:"utf8"}).trim();
const initialDiff = execFileSync("git",["diff","--binary","HEAD"],{cwd:checkout});
const expectedDiff = await readFile("/private/tmp/cb-stop-owner-candidate.patch");
if(git(["rev-parse","--short=9","HEAD"])!==head || !initialDiff.equals(expectedDiff)) throw new Error("Qualification source differs from the exact candidate patch");
const invocation = invocationFromEnvironment();
if(!invocation) throw new Error("Full regression requires an invocation");
const require = createRequire(checkout+"/web/package.json");
const startedAt = new Date().toISOString();
await writeFile(prefix+"-metadata.json",JSON.stringify({head,checkout,invocation,startedAt,maxWorkers:2,launcher:"native-node",dockerCli:execFileSync("docker",["--version"],{encoding:"utf8"}).trim()},null,2)+"\n");
await registerProcess(invocation,{role:"runner",caseName:"frozen-full-integration",rootRole:"invocation",root:null,bootId:invocation.id,logFile:prefix+".log"},process.pid);
const reaper = await retainLaneReaper(new AbortController().signal);
console.log(JSON.stringify({event:"lane-reaper-retained",invocationId:invocation.id,...reaper}));
const child = spawn(process.execPath,["--import",FIXTURE_WATCHDOG,require.resolve("vitest/package.json").replace(/package\.json$/, "vitest.mjs"),"run","--project","integration","--maxWorkers=2","--reporter=default","--reporter=json","--outputFile.json="+prefix+".json"],{cwd:checkout+"/web",env:{...process.env,...await fixtureProcessEnvironment(invocation)},stdio:"inherit",detached:true});
const outcomePromise = new Promise((resolve,reject)=>{child.once("error",reject);child.once("exit",(code,signal)=>resolve({code,signal}));});
void outcomePromise.catch(()=>{});
await registerProcess(invocation,{role:"vitest",caseName:"frozen-full-integration",rootRole:"invocation",root:null,bootId:invocation.id,logFile:prefix+".log"},child.pid);
const outcome = await outcomePromise;
const cleanup = await releaseInvocation(invocation,"frozen full integration completion");
let build = null;
try {build=JSON.parse(await readFile(checkout+"/web/.next/.maister-lane-build","utf8"));} catch(error) {if(error.code!=="ENOENT") throw error;}
const metadata={head,checkout,invocation,startedAt,finishedAt:new Date().toISOString(),maxWorkers:2,outcome,build,sourceHeadUnchanged:git(["rev-parse","--short=9","HEAD"])===head,candidateUnchanged:execFileSync("git",["diff","--binary","HEAD"],{cwd:checkout}).equals(expectedDiff),cleanupErrors:cleanup.map(e=>({name:e.name,message:e.message}))};
await writeFile(prefix+"-metadata.json",JSON.stringify(metadata,null,2)+"\n");
console.log(JSON.stringify({event:"frozen-full-complete",...metadata}));
process.exitCode=outcome.code===0&&cleanup.length===0?0:1;
