import { spawn, execFileSync } from "node:child_process";
import { writeFile, readFile } from "node:fs/promises";
import { createRequire } from "node:module";
import {
  invocationFromEnvironment, fixtureProcessEnvironment, registerProcess,
  releaseInvocation, FIXTURE_WATCHDOG,
} from "/private/tmp/maister-cb1-work-intake-1640/web/test-support/process-invocation.ts";
const checkout = "/private/tmp/maister-cb1-work-intake-1640";
const head = "1b91e392028fbc8240543cd3408bc74ff3ae7b97";
const prefix = "/private/tmp/cb-1b91e3920-frozen-full-web-integration";
const git = (args) => execFileSync("git",args,{cwd:checkout,encoding:"utf8"}).trim();
if(git(["rev-parse","HEAD"])!==head || git(["status","--porcelain"])) throw new Error("Qualification source must be the exact clean committed checkout");
const invocation = invocationFromEnvironment();
if(!invocation) throw new Error("Full regression requires an invocation");
const require = createRequire(checkout+"/web/package.json");
const startedAt = new Date().toISOString();
await writeFile(prefix+"-metadata.json",JSON.stringify({head,checkout,invocation,startedAt,maxWorkers:6},null,2)+"\n");
await registerProcess(invocation,{role:"runner",caseName:"frozen-full-integration",rootRole:"invocation",root:null,bootId:invocation.id,logFile:prefix+".log"},process.pid);
const child = spawn(process.execPath,["--import",FIXTURE_WATCHDOG,require.resolve("vitest/package.json").replace(/package\.json$/, "vitest.mjs"),"run","--project","integration","--maxWorkers=6","--reporter=default","--reporter=json","--outputFile.json="+prefix+".json"],{cwd:checkout+"/web",env:{...process.env,...await fixtureProcessEnvironment(invocation)},stdio:"inherit",detached:true});
const outcomePromise = new Promise((resolve,reject)=>{child.once("error",reject);child.once("exit",(code,signal)=>resolve({code,signal}));});
void outcomePromise.catch(()=>{});
await registerProcess(invocation,{role:"vitest",caseName:"frozen-full-integration",rootRole:"invocation",root:null,bootId:invocation.id,logFile:prefix+".log"},child.pid);
const outcome = await outcomePromise;
const cleanup = await releaseInvocation(invocation,"frozen full integration completion");
let build = null;
try {build=JSON.parse(await readFile(checkout+"/web/.next/.maister-lane-build","utf8"));} catch(error) {if(error.code!=="ENOENT") throw error;}
const metadata={head,checkout,invocation,startedAt,finishedAt:new Date().toISOString(),maxWorkers:6,outcome,build,sourceHeadUnchanged:git(["rev-parse","HEAD"])===head,cleanSource:git(["status","--porcelain"])==="",cleanupErrors:cleanup.map(e=>({name:e.name,message:e.message}))};
await writeFile(prefix+"-metadata.json",JSON.stringify(metadata,null,2)+"\n");
console.log(JSON.stringify({event:"frozen-full-complete",...metadata}));
process.exitCode=outcome.code===0&&cleanup.length===0?0:1;
