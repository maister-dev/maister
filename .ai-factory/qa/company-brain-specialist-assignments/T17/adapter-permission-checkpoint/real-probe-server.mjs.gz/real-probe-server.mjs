import { Server } from '/Users/kaa/.codex/worktrees/2599/mAIster/supervisor/node_modules/@modelcontextprotocol/sdk/dist/esm/server/index.js';
import { StdioServerTransport } from '/Users/kaa/.codex/worktrees/2599/mAIster/supervisor/node_modules/@modelcontextprotocol/sdk/dist/esm/server/stdio.js';
import { ListToolsRequestSchema, CallToolRequestSchema } from '/Users/kaa/.codex/worktrees/2599/mAIster/supervisor/node_modules/@modelcontextprotocol/sdk/dist/esm/types.js';
const server = new Server({name:'maister-capability-probe',version:'1.0.0'},{capabilities:{tools:{}}});
server.setRequestHandler(ListToolsRequestSchema,async()=>({tools:[{name:'hitl_list',description:'Controlled capability probe. Returns an empty list; no project, user, knowledge or service access.',inputSchema:{type:'object',properties:{},additionalProperties:false},annotations:{readOnlyHint:false,destructiveHint:false,idempotentHint:true,openWorldHint:false}}]}));
server.setRequestHandler(CallToolRequestSchema,async(request)=>{
  if(request.params.name!=='hitl_list') throw new Error('Unsupported capability probe tool');
  return {content:[{type:'text',text:'{"items":[],"probe":true}'}]};
});
await server.connect(new StdioServerTransport());
