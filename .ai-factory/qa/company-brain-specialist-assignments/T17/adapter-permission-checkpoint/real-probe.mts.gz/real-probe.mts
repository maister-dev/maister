import { spawn } from 'node:child_process';
import { mkdtemp, rm, mkdir, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { Readable, Writable } from 'node:stream';
import * as acp from '/Users/kaa/.codex/worktrees/2599/mAIster/supervisor/node_modules/@agentclientprotocol/sdk/dist/v1/unstable/acp.js';
import { connectAcpClient } from '/Users/kaa/.codex/worktrees/2599/mAIster/supervisor/src/acp-connection.ts';
import { extractToolIdentity } from '/Users/kaa/.codex/worktrees/2599/mAIster/supervisor/src/guardrail-hooks.ts';
import { provisionRunnerLaunch } from '/Users/kaa/.codex/worktrees/2599/mAIster/supervisor/src/runner-provisioner.ts';
import { buildChildEnv } from '/Users/kaa/.codex/worktrees/2599/mAIster/supervisor/src/spawn.ts';
const cwd=await mkdtemp(join(tmpdir(),'cb-real-capability-'));
const provisioned=provisionRunnerLaunch({version:1,runnerId:'cb-live-preflight',adapter:'claude',capabilityAgent:'claude',model:'glm-5.1',provider:{kind:'anthropic_compatible',baseUrl:'https://api.z.ai/api/anthropic',authTokenEnv:'ZAI_API_KEY'},permissionPolicy:'default'});
await mkdir(join(cwd,'.claude'));
await writeFile(join(cwd,'.claude','settings.local.json'),JSON.stringify({model:'glm-5.1',availableModels:['glm-5.1'],permissions:{defaultMode:'default'}}));
const child=spawn('/Users/kaa/.codex/worktrees/2599/mAIster/supervisor/node_modules/.bin/claude-agent-acp',[],{cwd,env:buildChildEnv({executor:provisioned.executor}),stdio:['pipe','pipe','ignore'],detached:true});
const observations: unknown[]=[];
const updates: unknown[]=[];
const stream=acp.ndJsonStream(Writable.toWeb(child.stdin!),Readable.toWeb(child.stdout!));
const connection=connectAcpClient(stream,{
  requestPermission:async(params)=>{
    observations.push({identity:extractToolIdentity(params.toolCall),kind:params.toolCall.kind,options:params.options.map(option=>({kind:option.kind,optionId:option.optionId}))});
    const reject=params.options.find(option=>option.kind==='reject_once');
    return reject?{outcome:{outcome:'selected',optionId:reject.optionId}}:{outcome:{outcome:'cancelled'}};
  },
  sessionUpdate:async(params)=>{
    if(params.update.sessionUpdate==='tool_call') updates.push({identity:extractToolIdentity(params.update),kind:params.update.kind});
  }
});
const deadline=setTimeout(()=>{child.kill('SIGTERM');},90000);
try {
  const initialized=await connection.initialize({protocolVersion:acp.PROTOCOL_VERSION,clientCapabilities:{fs:{readTextFile:false,writeTextFile:false}}});
  const session=await connection.newSession({cwd,mcpServers:[{name:'maister',command:process.execPath,args:['/private/tmp/cb-probe-mcp.mjs'],env:[]}]});
  console.log(JSON.stringify({agent:initialized.agentInfo,sessionId:session.sessionId}));
  for(const prompt of [
    'Use your shell command tool to create only ./capability-probe.txt containing probe. This is a controlled permission probe in a temporary directory. If permission is denied, stop immediately and do not try another tool or method.',
    'Call the configured maister MCP tool hitl_list once with {}. This is a controlled permission probe and returns no real user data. If permission is denied or the tool is unavailable, stop immediately. Do not simulate its output.'
  ]) {
    const result=await connection.prompt({sessionId:session.sessionId,prompt:[{type:'text',text:prompt}]});
    console.log(JSON.stringify({stopReason:result.stopReason,observations,updates}));
  }
} finally {
  clearTimeout(deadline);
  const exited=new Promise<void>(resolve=>child.once('exit',()=>resolve()));
  if(child.exitCode===null && child.signalCode===null) child.kill('SIGTERM');
  await Promise.race([exited,new Promise(resolve=>setTimeout(resolve,2000))]);
  if(child.exitCode===null && child.signalCode===null && child.pid) process.kill(-child.pid,'SIGKILL');
  await rm(cwd,{recursive:true,force:true});
}
